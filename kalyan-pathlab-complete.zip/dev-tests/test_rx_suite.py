import json, os, urllib.parse
from playwright.sync_api import sync_playwright
from PIL import Image
Image.new('RGB',(900,1200),'white').save('/tmp/rx_ok.png'); Image.new('RGB',(901,1201),'white').save('/tmp/rx_ok2.png')
open('/tmp/rx_note.txt','w').write('not an image')
open('/tmp/rx_big.pdf','wb').write(b'%PDF-1.4\n'+b'0'*(3*1024*1024+500))
RES=[]; posts=[]; backend={'mode':'text','text':''}
def row(n,stage,verdict,note=''): RES.append((n,stage,verdict,note)); print(f"{'PASS' if verdict else 'FAIL'}  [{stage:<9}] {n}{(' — '+note) if note else ''}")
with sync_playwright() as p:
    b=p.chromium.launch()
    for devname,ctxargs in [('desktop-sized',dict(viewport={'width':390,'height':780})),('Android Pixel 7',p.devices['Pixel 7'])]:
        ctx=b.new_context(service_workers='block',**ctxargs)
        def h(r):
            u=r.request.url
            if 'script.google.com' in u and r.request.method=='POST':
                d=json.loads(r.request.post_data)
                if d.get('type')=='ocrPrescription':
                    posts.append(d); m=backend['mode']
                    if m=='text': return r.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':True,'text':backend['text']}),headers={'access-control-allow-origin':'*'})
                    if m=='fail': return r.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':False,'error':'api_error'}),headers={'access-control-allow-origin':'*'})
                    if m=='limit': return r.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':False,'error':'limit'}),headers={'access-control-allow-origin':'*'})
                    if m=='html': return r.fulfill(status=200,content_type='text/html',body='<html>Sign in</html>',headers={'access-control-allow-origin':'*'})
                    if m=='old': return r.fulfill(status=200,content_type='application/json',body='{"ok":true}',headers={'access-control-allow-origin':'*'})
                    if m=='null': return r.fulfill(status=200,content_type='application/json',body='null',headers={'access-control-allow-origin':'*'})
                    if m=='abort': return r.abort()
                return r.fulfill(status=200,body='{}')
            return r.continue_() if u.startswith('http://localhost') else r.abort()
        ctx.route('**/*',h); pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('http://localhost:8765/',wait_until='load'); pg.evaluate("localStorage.clear();localStorage.setItem('kp_lang','mr')"); pg.reload(wait_until='load'); pg.wait_for_timeout(300)
        print(f"\n=========== {devname} ===========")
        M=lambda t,master=None: pg.evaluate("([t,m])=>matchPrescriptionTests(t,m||undefined).map(s=>s.confidence[0]+':'+s.test.name)",[t,master])
        names=lambda r:[x.split(':',1)[1] for x in r]
        if devname=='desktop-sized':
            # ---------------- MATCHING scenarios (OCR text given) ----------------
            r=M("Dr. A. Joshi MD\nAdv: CBC, HbA1c, Lipid Profile, TSH, Vitamin B12\nUrine routine\nTab Metformin 500 mg BD"); n=names(r)
            row('1 clear English prescription','matching',all(any(k in x for x in n) for k in ['Complete Blood Count','HbA1c','Lipid','TSH','B12']) , f"{len(r)} found")
            r=M("Inv: FBS, PPBS, LFT, KFT, ESR, CRP, Urine R/M"); n=names(r)
            row('2 abbreviations (FBS PPBS LFT KFT ESR CRP URM)','matching',all(any(k in x for x in n) for k in ['Fasting','PP','Liver','Kidney','ESR','CRP','Urine']), ', '.join(x[:22] for x in n))
            r=M("Adv\n- c r p\n- cbc.\n- tsh\n- S< R/m\n- x ray chest AP\nsyp combiflam"); row('3 unclear/handwritten-style text: finds what is legible, ignores the rest','matching',any('CBC' in x for x in names(r)) and not any('ray' in x.lower() for x in names(r)), f"{len(r)} found: "+', '.join(x[:20] for x in names(r)))
            r=M("Tab Iron 100 mg OD\nCap Calcium 500 mg BD\nDr. Alt Sharma MBBS\nSyp Cough 5 ml TDS\nReview after 5 days"); row('4 no lab tests (medicines/doctor/iron/calcium/ALT-named doctor) -> nothing','matching',len(r)==0, f"{len(r)} found")
            r=M("CBC, CBC, Complete Blood Count, cbc"); row('5 duplicate test names -> one entry','matching',len([x for x in names(r) if 'Complete Blood Count' in x])==1)
            master=pg.evaluate("TEST_CATEGORIES.flatMap(c=>c.tests).filter(t=>!/HbA1c/i.test(t.name)).slice(0,40)")
            r=M("HbA1c, PET scan, MRI brain, HLA-B27, CBC",master); n=names(r); row('6 test absent from master (HbA1c removed) is NOT invented; others still match','matching',not any('HbA1c' in x for x in n) and any('CBC' in x or 'Complete Blood' in x for x in n), f"{len(r)} found")
            r=M("Dr R C Shah\nAdv BS < F PP"); row('(extra) your real printed photo text "Adv BS < F PP" -> FBS + PP','matching',any('Fasting' in x for x in names(r)) and any('PP' in x for x in names(r)))
        # ---------------- UI / OCR scenarios ----------------
        pg.evaluate("showSection('tests',true)")
        def start(file=None):
            pg.click('#rxCta'); 
            if file: pg.set_input_files('#rxFile',file)
        def status(): return pg.inner_text('#rxStatus')
        def diag(): return pg.evaluate("KPRx.diag.stage+'/'+KPRx.diag.error")
        backend['mode']='text'; backend['text']="Adv: CBC, CRP, FBS"; posts.clear()
        start('/tmp/rx_ok.png'); pg.click('#rxScan'); pg.wait_for_timeout(900)
        row(f'[{devname}] upload -> preview shown, scan, tests listed for review','ocr+match',pg.is_visible('#rxPrev') and pg.locator('.rx-row').count()>=3 and 'Review' not in '' , diag())
        # duplicate request protection
        pg.click('#rxClose'); posts.clear(); start('/tmp/rx_ok2.png'); pg.evaluate("document.getElementById('rxScan').click(); document.getElementById('rxScan').click(); document.getElementById('rxScan').click();"); pg.wait_for_timeout(900)
        row(f'[{devname}] triple-tap on Scan -> only 1 backend request','reliability',len(posts)==1, f"{len(posts)} request(s)")
        # add twice -> no duplicates
        pg.evaluate("selectedTests.length=0"); pg.click('#rxAdd'); pg.wait_for_timeout(800); pg.evaluate("document.getElementById('bucketSheet') && (document.getElementById('bucketSheet').hidden=true)")
        n1=pg.evaluate("selectedTests.length"); pg.click('#rxCta'); pg.click('#rxScan'); pg.wait_for_timeout(300)
        pg.evaluate("document.querySelectorAll('#rxResults input:checked:not(:disabled)').forEach(c=>c.click())")
        n2=pg.evaluate("selectedTests.length"); row(f'[{devname}] adding suggestions twice never duplicates basket entries','reliability',n1==n2 and n1>=3, f"{n1} -> {n2}")
        pg.click('#rxClose')
        if devname=='desktop-sized':
            pg.click('#rxCta'); pg.set_input_files('#rxFile','/tmp/rx_note.txt'); pg.wait_for_timeout(200)
            row('7 invalid file type (.txt) rejected, scan disabled','validation','अजून' in '' or (pg.is_disabled('#rxScan') and 'JPG' in status() or 'PDF' in status()), status()[:60])
            pg.set_input_files('#rxFile','/tmp/rx_big.pdf'); pg.wait_for_timeout(200)
            row('8 PDF over 3 MB rejected before upload','validation',pg.is_disabled('#rxScan') and ('3' in status() or 'MB' in status()), status()[:60])
            pg.click('#rxClose')
            for mode,label,codes in [('fail','9 OCR service failure (api_error)','ocr-failed/api_error'),('limit','9b daily limit reached','ocr-failed/limit'),('html','10a malformed response (HTML, not JSON)','ocr-failed/bad_response'),('old','10b old backend ({ok:true}, no text)','ocr-failed/old_backend'),('null','10c backend returns null','ocr-failed/bad_response'),('abort','9c network failure','ocr-failed/network')]:
                backend['mode']=mode; pg.click('#rxCta'); pg.set_input_files('#rxFile','/tmp/rx_ok.png'); pg.click('#rxScan'); pg.wait_for_timeout(900)
                row(label+' -> friendly message + manual typing opens','ocr',diag()==codes and pg.evaluate("document.getElementById('rxType').open") and len(status())>10, f"{diag()} | {status()[:50]}")
                pg.click('#rxClose')
            backend['mode']='text'; backend['text']=''
            pg.click('#rxCta'); pg.set_input_files('#rxFile','/tmp/rx_ok.png'); pg.evaluate("document.getElementById('rxScan').click()"); pg.wait_for_timeout(900)
            row('(extra) OCR read nothing (empty text) is reported as OCR problem, not a matching problem','ocr',diag()=='empty-ocr/' ,diag()); pg.click('#rxClose')
            backend['mode']='fail'; pg.click('#rxCta'); pg.set_input_files('#rxFile','/tmp/rx_ok.png'); pg.click('#rxScan'); pg.wait_for_timeout(700)
            pg.fill('#rxTypeBox','CBC, FBS, PP'); pg.click('#rxTypeGo'); pg.wait_for_timeout(300)
            row('12 manual entry after OCR failure -> tests suggested and can be added','manual',pg.locator('.rx-row').count()>=3 and diag().startswith('matched'), diag()); pg.click('#rxClose')
            pg.evaluate("selectedTests.length=0"); pg.evaluate("showSection('tests',true)"); pg.click('#categoryTabs button >> nth=1'); pg.click('#testModalBody .test-add-btn >> nth=0'); 
            row('12b manual test selection still works independently of OCR','manual',pg.evaluate("selectedTests.length")==1)
        else:
            cam=pg.evaluate("(()=>{const c=document.getElementById('rxCamFile');return c.getAttribute('capture')+'|'+c.accept})()")
            row('11 Android (Pixel 7 emulation): camera input uses rear camera (capture=environment, image/*)','android','environment' in cam and 'image/*' in cam, cam)
            backend['mode']='text'; backend['text']='Adv CBC, TSH'; pg.click('#rxCta'); pg.set_input_files('#rxCamFile','/tmp/rx_ok.png'); pg.click('#rxScan'); pg.wait_for_timeout(900)
            row('11b Android: photo from camera input scanned and tests listed','android',pg.locator('.rx-row').count()>=2, diag()); pg.click('#rxClose')
        row(f'[{devname}] no JS errors','runtime',not errs, str(errs)[:80] if errs else '')
        ctx.close()
    b.close()
bad=[r for r in RES if not r[2]]
print(f"\nTOTAL {len(RES)} | PASS {len(RES)-len(bad)} | FAIL {len(bad)}")
for r in bad: print('  FAILED:',r[0],'|',r[3])
