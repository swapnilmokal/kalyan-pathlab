const fs=require('fs');
function mkSheet(rows){ const s={rows:rows.map(r=>r.slice()),
  getLastRow(){return s.rows.length}, appendRow(r){s.rows.push(r.slice())}, deleteRow(n){s.rows.splice(n-1,1)}, setFrozenRows(){},
  getRange(r,c,nr=1,nc=1){ return { getValues(){ return s.rows.slice(r-1,r-1+nr).map(row=>{const o=[];for(let i=0;i<nc;i++)o.push(row[c-1+i]===undefined?'':row[c-1+i]);return o;}) },
    setValues(v){ v.forEach((vr,i)=>{ s.rows[r-1+i]=s.rows[r-1+i]||[]; vr.forEach((x,j)=>s.rows[r-1+i][c-1+j]=x)}) },
    setValue(x){ s.rows[r-1]=s.rows[r-1]||[]; s.rows[r-1][c-1]=x }, getValue(){ return (s.rows[r-1]||[])[c-1]===undefined?'':s.rows[r-1][c-1] },
    setFontWeight(){return this},setBackground(){return this},setFontColor(){return this} } } }; return s; }
const bookings=mkSheet([
 ['Timestamp','Name','Phone','Alt','Address','City','Loc','Doctor','Date','Time','Report','Email','Tests','Amount','Rx','PID','Pay','Status','ReportLink','Age'],
 ['t','Sunita','9876543210','','Flat 4','Kalyan','','Dr J','2026-10-12','7 AM','WhatsApp','','CBC',299,'','KP1','Cash','Pending Confirmation','','42'],
 ['t','Ramesh','9123456780','','U3','Ulhas','','','2026-10-12','8 AM','WhatsApp','','HbA1c',399,'','KP2','UPI','Completed','https://drive.google.com/file/d/ABC123/view','55']]);
const sheets={Bookings:bookings}; const mails=[]; const props={}; let booked=0;
global.SpreadsheetApp={openById:()=>({getUrl:()=>'u',getSheetByName:n=>sheets[n]||null,insertSheet:n=>(sheets[n]=mkSheet([]))})};
global.ContentService={MimeType:{JSON:'json'},createTextOutput:s=>({s,setMimeType(){return this},getContent(){return s}})};
global.Utilities={formatDate:()=>'14/10/2026 10:00',base64Encode:b=>Buffer.from(b).toString('base64'),base64Decode:s=>[...Buffer.from(s,'base64')],newBlob:(b,m,n)=>({b,m,n})};
global.Session={getScriptTimeZone:()=> 'Asia/Kolkata'}; global.MailApp={sendEmail:m=>mails.push(m)}; global.LockService={getScriptLock:()=>({tryLock:()=>true,releaseLock(){}})};
global.PropertiesService={getScriptProperties:()=>({getProperty:k=>props[k]||null,setProperty:(k,v)=>props[k]=v})};
global.DriveApp={Access:{},Permission:{},getFileById:id=>({getName:()=>'Report.pdf',getBlob:()=>({getBytes:()=>[1,2,3],getContentType:()=>'application/pdf'}),setTrashed(){}})};
global.Drive={Files:{create:()=>({id:'DOC1'})}}; global.DocumentApp={openById:()=>({getBody:()=>({getText:()=>'CBC, FBS PP'})})};
global.getTestsFromSheet=()=>[]; global.getBillsFromSheet=()=>[]; global.getAllPatientProfiles_=()=>[]; global.getSettings_=()=>({upiId:'x@y'}); global.getReportsFolderUrl_=()=>'';
global.getApprovedReviews=()=>[]; global.savePrescriptionIfAny=undefined; global.getOrCreatePatientId=()=>({patientId:'KP9'}); global.sendBookingEmails=()=>{}; global.formatHeaderRow=()=>{}; global.saveBooking=()=>{booked++};
eval(fs.readFileSync('/tmp/Code_NEW.js','utf8')+'\n;global.doGet=doGet;global.doPost=doPost;');
const J=o=>JSON.parse(o.getContent()); const post=d=>doPost({postData:{contents:JSON.stringify(d)}});
let ok=true; const check=(n,c)=>{console.log((c?'PASS ':'FAIL ')+n); if(!c) ok=false;};
check('version route', J(doGet({parameter:{action:'version'}})).version==='2026-10-13');
const st=J(doGet({parameter:{action:'bookingStatus',phone:'9876543210'}})).bookings; check('patient status richer', st.length===1&&st[0].rowNum===2&&st[0].fullName==='Sunita');
post({type:'cancelBooking',rowNum:3,phone:'9123456780'}); check('cancel Completed refused', bookings.rows[2][17]==='Completed');
post({type:'cancelBooking',rowNum:2,phone:'1'}); check('cancel wrong phone refused', bookings.rows[1][17]==='Pending Confirmation');
post({type:'cancelBooking',rowNum:2,phone:'9876543210'}); check('cancel works + owner email', bookings.rows[1][17]==='Cancelled'&&mails.length===1);
check('report file', J(doGet({parameter:{action:'getReportFile',rowNum:'3',phone:'9123456780'}})).data==='AQID');
post({type:'markReportShared',rowNum:3,phone:'9123456780',via:'file'}); check('report-shared column 21', String(bookings.rows[2][20]).startsWith('14/10/2026'));
post({type:'adminAction',action:'saveClient',clientType:'CLIENT',name:'City Care',address:'A'}); post({type:'adminAction',action:'saveClient',clientType:'CLIENT',name:'city care',address:'B'});
const ad=J(doGet({parameter:{action:'adminData'}})); check('adminData clients (upsert) + reportShared', ad.clients.length===1&&ad.clients[0].address==='B'&&String(ad.bookings.find(b=>b.rowNum===3).reportShared).startsWith('14/10/2026'));
post({type:'booking',fullName:'New',phone:'9000000000'}); check('ORIGINAL booking flow still works', booked===1);
console.log(ok?'\nALL PASS':'\nSOME FAILED'); process.exit(ok?0:1);
