KALYAN PATHLAB — अपडेट (नवा प्रोजेक्ट नको; फक्त फाईल REPLACE)
=============================================================
या zip मध्ये
- book/            : अ‍ॅप (ग्राहक + admin)          -> GitHub वर जातं
- root-redirect/   : जुनी admin लिंक -> नवी           -> GitHub वर जाते
- github-workflow/ : unzip-book.yml (आधीपासून रिपोमध्ये असेल तर पुन्हा टाकू नका)
- apps-script/     : Apps Script च्या फाईल्स (2 txt + README)  -> GitHub वर टाकू नका

भाग 1 — GitHub  [Chrome मध्ये "Desktop site" चालू करा]
 1. रिपोमध्ये जुनी .zip असेल तर delete करा.
 2. Add file > Upload files > kalyan-pathlab-complete.zip (extract करू नका) > Commit changes.
 3. Actions टॅबमध्ये हिरवा टिक येईपर्यंत थांबा.

भाग 2 — Apps Script: apps-script/README_APPS_SCRIPT_MARATHI.txt मधल्या पायऱ्या (Code.gs आणि extras.gs फाईल REPLACE).
 config.js मध्ये काहीही बदलायचं नाही (extrasUrl रिकामी राहू द्या).

भाग 3 — फोनवर: जुनी दोन्ही अ‍ॅप्स काढून नवी install करा.
