KALYAN PATHLAB — अपडेट (प्रिस्क्रिप्शन-स्कॅन दुरुस्ती)
=====================================================
- book/        : अ‍ॅप (ग्राहक + admin)  -> GitHub वर जातं
- root-redirect/, github-workflow/ : आधीप्रमाणे
- apps-script/ : Code.gs ची नवी फाईल + README + TEST_CHECKLIST (GitHub वर टाकू नका)
- dev-tests/   : विकसकांसाठी चाचण्या (GitHub वर जात नाहीत)

1) Apps Script (आधी)  : apps-script/README_APPS_SCRIPT_MARATHI.txt च्या पायऱ्या 1–6.
2) GitHub (नंतर)       : जुनी .zip delete > Add file > Upload files > ही zip (extract करू नका) > Commit > Actions हिरवा.
3) फोनवर              : अ‍ॅप बंद करून पुन्हा उघडा (जुनं दिसलं तर साईट डेटा साफ करा).
4) चाचणी              : apps-script/TEST_CHECKLIST_MARATHI.txt
