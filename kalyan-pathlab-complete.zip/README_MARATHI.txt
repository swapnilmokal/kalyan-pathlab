KALYAN PATHLAB — संपूर्ण अपडेट (एकाच zip मध्ये)
==================================================

या zip मध्ये काय आहे
- book/              : ग्राहक अ‍ॅप + admin अ‍ॅप + सर्व आयकॉन्स (GitHub वर जातं)
- root-redirect/     : रिपोच्या मुख्य फोल्डरमधली जुनी admin.html बदलणारी redirect फाईल (GitHub वर जाते)
- github-workflow/   : unzip-book.yml (GitHub Actions फाईल — एकदाच रिपोमध्ये टाकायची)
- apps-script/       : Code_gs_updated.txt (फक्त Google Apps Script मध्ये paste करायचा — GitHub वर टाकू नका)

अ) एकदाच (ही zip पहिल्यांदा वापरताना)
1. GitHub रिपो उघडा (Desktop site चालू करून). Settings > Actions > General > Workflow permissions > "Read and write permissions" > Save.
2. रिपोवर Add file > Create new file. नाव:  .github/workflows/unzip-book.yml
   github-workflow/unzip-book.yml मधला पूर्ण मजकूर paste करा > Commit changes.
   (आधीची फाईल असेल तर तिचा मजकूर नव्यानं बदला.)

ब) प्रत्येक अपडेटसाठी
1. ही zip (kalyan-pathlab-complete.zip) रिपोच्या मुख्य पानावर Add file > Upload files ने upload करा. extract करू नका.
2. Commit changes. Actions टॅबमध्ये हिरवा टिक येईपर्यंत थांबा. zip आपोआप निघून जाते आणि book/ अपडेट होतो.
3. 2-3 मिनिटांनी अ‍ॅप उघडा.

क) Google Apps Script (रद्द करणे + क्लायंट सेव्हसाठी आवश्यक)
1. script.google.com > तुमचा प्रोजेक्ट > Code.gs चा सगळा मजकूर काढा.
2. apps-script/Code_gs_updated.txt चा मजकूर paste करा > Save.
3. Deploy > Manage deployments > पेन्सिल > Version: New version > Deploy. (लिंक बदलत नाही.)

ड) फोनवर अ‍ॅप्स
- ग्राहक अ‍ॅप : https://swapnilmokal.github.io/kalyan-pathlab/book/index.html
- Admin अ‍ॅप  : https://swapnilmokal.github.io/kalyan-pathlab/book/admin.html
- जुनी दोन्ही अ‍ॅप्स काढून नवी पुन्हा install करा. Chrome चा साईट डेटा साफ करा.
