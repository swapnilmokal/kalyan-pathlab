KALYAN PATHLAB — संपूर्ण अपडेट (एकाच zip मध्ये)
==================================================
zip मध्ये काय आहे
- book/            : ग्राहक अ‍ॅप + admin अ‍ॅप + मूळ लोगो/आयकॉन्स (GitHub वर जातं)
- root-redirect/   : मुख्य फोल्डरमधली जुनी admin.html बदलणारी फाईल (GitHub वर जाते)
- github-workflow/ : unzip-book.yml (आधीपासून रिपोमध्ये असेल तर पुन्हा टाकायची गरज नाही)
- apps-script/     : Code_gs_updated.txt (फक्त Google Apps Script मध्ये paste करायचा; GitHub वर टाकू नका)

अ) GitHub वर अपडेट (ब्राउझरमध्ये "Desktop site" चालू करून)
1. रिपोमध्ये जुनी कोणतीही .zip फाईल असेल तर आधी delete करा.
2. रिपोच्या मुख्य पानावर Add file > Upload files > kalyan-pathlab-complete.zip (extract करू नका) > Commit changes.
3. Actions टॅबमध्ये हिरवा टिक येईपर्यंत थांबा. zip आपोआप निघून जाते आणि book/ अपडेट होतो.
4. Actions लाल झालं तर त्याचा स्क्रीनशॉट मला पाठवा.

ब) Google Apps Script (प्रिस्क्रिप्शन-स्कॅनसाठी या वेळी पुन्हा paste करा + एक सेटिंग)
1. script.google.com > प्रोजेक्ट > Code.gs चा सगळा मजकूर काढून apps-script/Code_gs_updated.txt चा मजकूर paste करा > Save.
2. Deploy > Manage deployments > पेन्सिल > Version: New version > Deploy.

क) फोनवर
- ग्राहक अ‍ॅप : https://swapnilmokal.github.io/kalyan-pathlab/book/index.html
- Admin अ‍ॅप  : https://swapnilmokal.github.io/kalyan-pathlab/book/admin.html
- जुनी दोन्ही अ‍ॅप्स काढून नवी install करा. Chrome चा साईट डेटा साफ करा.

ड) Admin बायोमेट्रिक लॉक
- Admin मध्ये PIN टाकून उघडा > Settings > "बायोमेट्रिक लॉक" > "चालू करा". पुढच्या वेळी अ‍ॅप उघडताच फिंगरप्रिंट/फेस विचारतो; जमलं नाही तर PIN चालतो.

इ) प्रिस्क्रिप्शनवरून टेस्ट शोधा (नवी सोय) — Apps Script मध्ये एकदाच करायचं
1. Code.gs मध्ये नवी Code_gs_updated.txt paste करा > Save.
2. डावीकडे "Services" (+) > "Drive API" निवडा > Add. (v3 किंवा v2 दोन्ही चालतात)
3. Deploy > Manage deployments > पेन्सिल > New version > Deploy. परवानगी विचारली तर द्या (Google Docs/Drive).
4. अ‍ॅपमध्ये टेस्ट पेजवर "प्रिस्क्रिप्शनवरून टेस्ट शोधा" किंवा बुकिंग पायरी १ मध्ये प्रिस्क्रिप्शन निवडून हे वापरा.
टीप: छापील प्रिस्क्रिप्शन चांगलं वाचलं जातं; हस्ताक्षर अस्पष्ट असल्यास चूक होऊ शकते — म्हणून पेशंट तपासून टेस्ट निवडतो.
