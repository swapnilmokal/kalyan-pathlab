KALYAN PATHLAB — अपडेट: काय करायचं (सोप्या पायऱ्या)
====================================================
या zip मध्ये
- book/            : अ‍ॅप (ग्राहक + admin)  -> GitHub वर जातं
- root-redirect/   : जुनी admin लिंक नव्या कडे नेणारी फाईल -> GitHub वर जाते
- github-workflow/ : unzip-book.yml (रिपोमध्ये आधीपासून असेल तर पुन्हा टाकू नका)
- apps-script/     : Extras_gs.txt -> फक्त Google Apps Script मध्ये (GitHub वर टाकू नका)

भाग १ — GitHub (अ‍ॅप अपडेट)    [Chrome मध्ये "Desktop site" चालू करा]
 1. रिपोमध्ये जुनी कोणतीही .zip असेल तर delete करा.
 2. Add file > Upload files > ही zip (kalyan-pathlab-complete.zip) निवडा. extract करू नका.
 3. Commit changes. Actions टॅबमध्ये हिरवा टिक येईपर्यंत थांबा.

भाग २ — Google Apps Script  (रद्द करणे, रिपोर्ट शेअर, क्लायंट सेव्ह, प्रिस्क्रिप्शन-स्कॅन साठी)
 १. script.google.com > तुमचा प्रोजेक्ट उघडा.
 २. डावीकडे "Files" च्या शेजारी  +  > Script > नाव द्या:  Extras
 ३. apps-script/Extras_gs.txt मधला सगळा मजकूर कॉपी करून Extras फाईलमध्ये paste करा (आधीचा रिकामा मजकूर काढा). Save.
 ४. आता तुमच्या जुन्या फाईलमध्ये (जिथे  function doGet(e)  आणि  function doPost(e)  आहे) फक्त दोन नावं बदला:
        function doGet(e)   ->  function doGetBase_(e)
        function doPost(e)  ->  function doPostBase_(e)
    (आतला बाकी कोड जसाच्या तसा ठेवा. दोन्ही शब्द एकाच फाईलमध्ये नसतील तर ज्या फाईलमध्ये सापडतील तिथे बदला.)
 ५. डावीकडे "Services" ( + ) > Drive API > Add.   (प्रिस्क्रिप्शन-स्कॅनसाठी)
 ६. वरती Deploy > Manage deployments > पेन्सिल > Version: "New version" > Deploy.  परवानगी विचारली तर द्या.
 ७. तपासा: तुमची Apps Script लिंक ब्राउझरमध्ये उघडून शेवटी  ?action=version  जोडा.
    {"ok":true,"version":"2026-10-13","ocr":true,"driveApi":true}  दिसलं की झालं.
    (driveApi false असेल तर ५ वी पायरी पुन्हा करा.)

भाग ३ — फोनवर: जुनी दोन्ही अ‍ॅप्स काढून नवी install करा.
 ग्राहक: https://swapnilmokal.github.io/kalyan-pathlab/book/index.html
 Admin : https://swapnilmokal.github.io/kalyan-pathlab/book/admin.html
