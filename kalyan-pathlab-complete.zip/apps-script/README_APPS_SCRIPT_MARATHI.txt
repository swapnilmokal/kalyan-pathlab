APPS SCRIPT — प्रिस्क्रिप्शन-स्कॅन दुरुस्ती (मोबाईलवर फक्त फाईल REPLACE; एडिट नाही)
===========================================================================
बदलायच्या फाईल्स: फक्त Code.gs (आणि extras.gs रिकामी). बाकी फाईल्सना (Backend2/3/4/5, Code_old4) हात लावू नका.

1) Code.gs REPLACE
   "1_Code_gs_NEW_PASTE_IN_Code.gs.txt" चा सगळा मजकूर कॉपी करा > Apps Script मध्ये Code.gs उघडा >
   कोडमध्ये टॅप > लांब दाबा > Select all > Paste > Save.
2) extras.gs रिकामी (आधी केली नसेल तर)
   "2_extras_gs_EMPTY_PASTE_IN_extras.gs.txt" चा मजकूर extras.gs मध्ये Select all > Paste > Save.
3) Drive API (आधी जोडलेलं असेल तर वगळा)
   डावीकडे Services (+) > Drive API > Add.
4) परवानगी द्या (नवी पायरी — हीच अनेकदा कारण असते)
   वरच्या फंक्शन-ड्रॉपडाउन मधून  kpxAuthorize  निवडा > Run > "Review permissions" > तुमचं Google खातं > Allow.
   शेवटी Execution log मध्ये "OK — Drive API चालू" दिसलं पाहिजे.
5) Deploy
   Deploy > Manage deployments > तुमच्या (नव्या) deployment ची पेन्सिल > Version: "New version" > Deploy.
   (नवी deployment बनवू नका — नाहीतर URL पुन्हा बदलेल.)
6) तपासा
   Apps Script लिंक + ?action=version   →   {"ok":true,"version":"2026-10-13","ocr":true,"driveApi":true}

काय बदललं (Code.gs)
 • kpx_ocr_: फक्त JPEG/PNG/PDF; decode केलेला आकार ≤ 3 MB; चुकीचं base64, चुकीचा प्रकार, Drive API बंद, API एरर, रिकामा OCR निकाल — प्रत्येकाचा वेगळा कोड (bad_type, bad_base64, too_large, limit, drive_api_off, api_error, conversion_failed, ocr_failed).
 • Drive v3 (create + Google Doc + ocrLanguage) आणि v2 (insert + ocr:true + convert:true) — जे चालू असेल ते आपोआप.
 • तात्पुरता OCR Doc नेहमी (finally) कचऱ्यात. रुग्णाची कोणतीही माहिती Logger/console मध्ये लिहिली जात नाही.
 • रोजची मर्यादा (150) + lock; विनंतीचा आकार मर्यादित.
 • नवीन: रुग्णाचे प्रिस्क्रिप्शन फाईल्स आता "लिंक असलेल्या कोणालाही" उघडत नाहीत (खाजगी). फक्त तुमच्या Google खात्यातून उघडतात.
   जुनं वर्तन हवं असल्यास Code.gs च्या वरच्या भागात  KPX_PRESCRIPTIONS_PRIVATE = true  हे false करा.
   (रिपोर्ट फाईल्सचं शेअरिंग बदललेलं नाही.)

कोड-वाचन (diagnostic): अ‍ॅपच्या स्कॅन डायलॉगच्या तळाशी छोटी ओळ दिसते:  OCR: <अक्षरे> · Matches: <संख्या> · <स्थिती>
 स्थिती:  matched = सगळं ठीक | no-match = OCR ने मजकूर वाचला पण टेस्ट सापडल्या नाहीत (मॅचिंगचा प्रश्न)
          empty-ocr = फोटोतून मजकूरच वाचला गेला नाही (OCR/फोटोचा प्रश्न) | ocr-failed/<कोड> = बॅकएंड/नेटवर्क अडचण
