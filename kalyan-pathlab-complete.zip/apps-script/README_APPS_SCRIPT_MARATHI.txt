APPS SCRIPT — मोबाईलवर फक्त "फाईल REPLACE" (एडिट करायची गरज नाही)
=================================================================
तुमच्या प्रोजेक्टमध्ये: Backend3, Backend2, Backend4, Backend5, Code_old4, Code, extras
→ फक्त 2 फाईल्स बदलायच्या: Code.gs आणि extras.gs. बाकी सर्व फाईल्सना हात लावायचा नाही. नवा प्रोजेक्ट नको.

पायरी 1 — Code.gs पूर्ण बदला
 • "1_Code_gs_NEW_PASTE_IN_Code.gs.txt" ही फाईल उघडा > सगळा मजकूर निवडा (Select all) > Copy.
 • Apps Script मध्ये Code.gs उघडा > कोडमध्ये एकदा टॅप करा > लांब दाबा > "Select all" > "Paste". (जुना सगळा मजकूर पुसून नवा येईल.) Save (डिस्क आयकॉन).

पायरी 2 — extras.gs रिकामी करा
 • "2_extras_gs_EMPTY_PASTE_IN_extras.gs.txt" चा मजकूर कॉपी करा.
 • extras.gs उघडा > Select all > Paste. Save.
   (हे अत्यंत महत्त्वाचं: extras.gs मध्ये जुना paste केलेला कोड राहिला तर तो बाकी सगळ्या कोडवर भारी पडतो.)
   (हवं तर extras.gs फाईलच Delete करा.)

पायरी 3 — Drive API जोडा (प्रिस्क्रिप्शन-स्कॅनसाठी, फक्त एकदा)
 • डावीकडे "Services" च्या शेजारी + > "Drive API" > Add.

पायरी 4 — Deploy
 • वरती Deploy > Manage deployments > पेन्सिल > Version: "New version" > Deploy. परवानगी विचारली तर द्या.

पायरी 5 — तपासा
 • तुमची Apps Script लिंक (…/exec) ब्राउझरमध्ये उघडून शेवटी  ?action=version  जोडा.
   {"ok":true,"version":"2026-10-13","ocr":true,"driveApi":true}  दिसलं की झालं.
 • अ‍ॅपमधून एक टेस्ट बुकिंग करून पाहा; Sheet मध्ये ओळ आली का ते पाहा.

काही बिघडलं तर (परत मागे जायचं): Deploy > Manage deployments > पेन्सिल > Version मध्ये आधीची आवृत्ती निवडा > Deploy.
