/* =====================================================================
   Kalyan Pathlab — Admin: Professional Bill / Invoice generation
   - बुकिंग Confirmed/Completed झाल्यावर "🧾 Generate Bill"
   - B2C (पेशंट बिल: कलेक्शन चार्जसह) आणि B2B (क्लायंट/पार्टनर इनव्हॉइस)
   - डिफॉल्ट भाषा English; गोल स्टॅम्प "Kalyan Pathlab" च्या नावाने
   - प्रिंट / PDF: Chrome मध्ये Print → "Save as PDF"
   admin.js नंतर लोड होतो (admin.js मधले ALL_DATA, t, money, showToast, ... वापरतो).
   ===================================================================== */
(function () {
  "use strict";

  const LAB = KPInv.LAB;
  const FREE_MIN = 499;      // ₹499 किंवा जास्त = कलेक्शन चार्ज माफ
  const CHARGE = 100;        // ₹499 पेक्षा कमी = ₹100
  const CHARGE_LINE_NAME = "Home Sample Collection Charges";
  const PROFILE_KEY = "kp_lab_profile";

  /* ---------- Admin UI translations (en / mr / hi) ---------- */
  Object.assign(TRANSLATIONS, {
    ib_btn_bill: { en: "Generate Bill", mr: "बिल बनवा", hi: "बिल बनाएं" },
    ib_print_bill: { en: "Print Bill", mr: "बिल प्रिंट", hi: "बिल प्रिंट" },
    ib_title: { en: "Generate Bill", mr: "बिल बनवा", hi: "बिल बनाएं" },
    ib_type_b2c: { en: "B2C · Patient bill", mr: "B2C · पेशंट बिल", hi: "B2C · मरीज़ बिल" },
    ib_type_b2b: { en: "B2B · Client / partner", mr: "B2B · क्लायंट / पार्टनर", hi: "B2B · क्लाइंट / पार्टनर" },
    ib_lang: { en: "Bill language", mr: "बिलची भाषा", hi: "बिल की भाषा" },
    ib_patient: { en: "Patient details", mr: "पेशंट तपशील", hi: "मरीज़ विवरण" },
    ib_name: { en: "Patient name *", mr: "पेशंटचे नाव *", hi: "मरीज़ का नाम *" },
    ib_age: { en: "Age", mr: "वय", hi: "उम्र" },
    ib_gender: { en: "Gender", mr: "लिंग", hi: "लिंग" },
    ib_mobile: { en: "Mobile", mr: "मोबाईल", hi: "मोबाइल" },
    ib_addr: { en: "Address", mr: "पत्ता", hi: "पता" },
    ib_doc: { en: "Referred by (Doctor / Self)", mr: "रेफर करणारे (डॉक्टर / स्वतः)", hi: "रेफर (डॉक्टर / स्वयं)" },
    ib_sample_date: { en: "Sample collection date", mr: "सॅम्पल कलेक्शन तारीख", hi: "सैंपल कलेक्शन तारीख" },
    ib_client: { en: "Billed to (client)", mr: "बिल कोणाला (क्लायंट)", hi: "बिल किसे (क्लाइंट)" },
    ib_client_name: { en: "Client / organisation name *", mr: "क्लायंट / संस्थेचे नाव *", hi: "क्लाइंट / संस्था का नाम *" },
    ib_client_addr: { en: "Client address", mr: "क्लायंटचा पत्ता", hi: "क्लाइंट का पता" },
    ib_client_gstin: { en: "Client GSTIN (if any)", mr: "क्लायंट GSTIN (असल्यास)", hi: "क्लाइंट GSTIN (यदि हो)" },
    ib_client_contact: { en: "Contact person / phone", mr: "संपर्क व्यक्ती / फोन", hi: "संपर्क व्यक्ति / फोन" },
    ib_tests: { en: "Tests", mr: "टेस्ट", hi: "टेस्ट" },
    ib_search: { en: "Search & add test…", mr: "टेस्ट शोधा व जोडा…", hi: "टेस्ट खोजें व जोड़ें…" },
    ib_custom_name: { en: "Custom test name", mr: "इतर टेस्टचे नाव", hi: "अन्य टेस्ट का नाम" },
    ib_add: { en: "+ Add", mr: "+ जोडा", hi: "+ जोड़ें" },
    ib_rate: { en: "Rate ₹", mr: "दर ₹", hi: "दर ₹" },
    ib_mrp: { en: "MRP ₹", mr: "MRP ₹", hi: "MRP ₹" },
    ib_no_lines: { en: "No tests added yet.", mr: "अजून टेस्ट जोडली नाही.", hi: "अभी कोई टेस्ट नहीं जुड़ी।" },
    ib_coll: { en: "Home collection charge ₹", mr: "होम कलेक्शन चार्ज ₹", hi: "होम कलेक्शन चार्ज ₹" },
    ib_coll_b2c: { en: "Auto: ₹100 below ₹499, waived at ₹499 and above (editable).", mr: "आपोआप: ₹499 पेक्षा कमी = ₹100, ₹499 किंवा जास्त = माफ (बदलता येतं).", hi: "अपने-आप: ₹499 से कम = ₹100, ₹499 या अधिक = माफ (बदल सकते हैं)।" },
    ib_coll_b2b: { en: "B2B default ₹0 (edit if needed).", mr: "B2B साठी डिफॉल्ट ₹0 (हवं तर बदला).", hi: "B2B के लिए डिफ़ॉल्ट ₹0 (चाहें तो बदलें)।" },
    ib_pay: { en: "Payment", mr: "पेमेंट", hi: "पेमेंट" },
    ib_pay_mode: { en: "Mode", mr: "पद्धत", hi: "तरीका" },
    ib_pay_status: { en: "Status", mr: "स्थिती", hi: "स्थिति" },
    ib_paid: { en: "Paid", mr: "भरले", hi: "चुकाया" },
    ib_unpaid: { en: "Unpaid / Due", mr: "बाकी", hi: "बाकी" },
    ib_lab: { en: "Lab details printed on bill", mr: "बिलावर छापले जाणारे लॅब तपशील", hi: "बिल पर छपने वाले लैब विवरण" },
    ib_lab_gstin: { en: "Lab GSTIN (optional)", mr: "लॅब GSTIN (ऐच्छिक)", hi: "लैब GSTIN (वैकल्पिक)" },
    ib_lab_reg: { en: "Registration / licence no.", mr: "नोंदणी / परवाना क्र.", hi: "पंजीकरण / लाइसेंस नं." },
    ib_lab_sign: { en: "Signatory (name / designation)", mr: "सही करणारे (नाव / पद)", hi: "हस्ताक्षरकर्ता (नाम / पद)" },
    ib_save_list: { en: "Also save to Bills list (profit tracking)", mr: "बिल्स यादीतही सेव्ह करा (प्रॉफिट ट्रॅकिंग)", hi: "बिल्स सूची में भी सेव करें (प्रॉफिट ट्रैकिंग)" },
    ib_b2b_nosave: { en: "B2B invoices are for printing only — not added to profit stats.", mr: "B2B इनव्हॉइस फक्त प्रिंटसाठी — प्रॉफिट आकडेवारीत जोडले जात नाहीत.", hi: "B2B इनवॉइस केवल प्रिंट के लिए — प्रॉफिट आँकड़ों में नहीं जुड़ते।" },
    ib_preview: { en: "Preview & Print", mr: "प्रीव्ह्यू व प्रिंट", hi: "प्रीव्यू व प्रिंट" },
    ib_back_edit: { en: "← Edit", mr: "← एडिट", hi: "← एडिट" },
    ib_print: { en: "🖨 Print", mr: "🖨 प्रिंट", hi: "🖨 प्रिंट" },
    ib_report_shared: { en: "Report shared by patient", mr: "पेशंटने रिपोर्ट शेअर केला", hi: "मरीज़ ने रिपोर्ट शेयर की" },
    ib_quote_btn: { en: "📄 New Quotation", mr: "📄 नवे कोटेशन", hi: "📄 नया कोटेशन" },
    ib_quote_title: { en: "Quotation", mr: "कोटेशन", hi: "कोटेशन" },
    ib_quote_date: { en: "Quotation date", mr: "कोटेशनची तारीख", hi: "कोटेशन की तारीख" },
    ib_valid_till: { en: "Valid till", mr: "वैधता (तारखेपर्यंत)", hi: "वैधता (तारीख तक)" },
    ib_notes: { en: "Note on quotation (optional)", mr: "कोटेशनवरची टीप (ऐच्छिक)", hi: "कोटेशन पर टिप्पणी (वैकल्पिक)" },
    ib_email_f: { en: "Email", mr: "ईमेल", hi: "ईमेल" },
    ib_pref_sample: { en: "Preferred sample date (optional)", mr: "पसंतीची सॅम्पल तारीख (ऐच्छिक)", hi: "पसंदीदा सैंपल तारीख (वैकल्पिक)" },
    ib_quote_preview: { en: "Preview & Share", mr: "प्रीव्ह्यू व शेअर", hi: "प्रीव्यू व शेयर" },
    ib_email_btn: { en: "✉️ Email", mr: "✉️ ईमेल", hi: "✉️ ईमेल" },
    ib_pdf: { en: "⬇ PDF", mr: "⬇ PDF", hi: "⬇ PDF" },
    ib_share: { en: "📤 Share", mr: "📤 शेअर", hi: "📤 शेयर" },
    ib_wa: { en: "💬 WhatsApp", mr: "💬 WhatsApp", hi: "💬 WhatsApp" },
    ib_sub: { en: "Sub-total", mr: "उप-एकूण", hi: "उप-कुल" },
    ib_coll_line: { en: "Collection charge", mr: "कलेक्शन चार्ज", hi: "कलेक्शन चार्ज" },
    ib_net: { en: "Net payable", mr: "एकूण देय", hi: "कुल देय" },
    ib_waived: { en: "Waived", mr: "माफ", hi: "माफ" },
    ib_err_name: { en: "Enter patient name.", mr: "पेशंटचे नाव टाका.", hi: "मरीज़ का नाम डालें।" },
    ib_err_lines: { en: "Add at least one test.", mr: "किमान एक टेस्ट जोडा.", hi: "कम से कम एक टेस्ट जोड़ें।" },
    ib_err_client: { en: "Enter client / organisation name.", mr: "क्लायंट / संस्थेचे नाव टाका.", hi: "क्लाइंट / संस्था का नाम डालें।" },
    ib_bill_date: { en: "Bill date", mr: "बिलाची तारीख", hi: "बिल की तारीख" },
    ib_sample_time: { en: "Sample collection time", mr: "सॅम्पल कलेक्शन वेळ", hi: "सैंपल कलेक्शन समय" },
    ib_saved_clients: { en: "Saved clients (from sheet)", mr: "सेव्ह केलेले क्लायंट (शीटमधून)", hi: "सेव किए क्लाइंट (शीट से)" },
    ib_pick_client: { en: "— Select saved client —", mr: "— सेव्ह क्लायंट निवडा —", hi: "— सेव क्लाइंट चुनें —" },
    ib_save_client: { en: "Save / update this client for next time", mr: "हा क्लायंट पुढच्या वेळेसाठी सेव्ह/अपडेट करा", hi: "यह क्लाइंट अगली बार के लिए सेव/अपडेट करें" },
    ib_client_saved: { en: "Client details saved to sheet ✓", mr: "क्लायंट तपशील शीटमध्ये सेव्ह झाले ✓", hi: "क्लाइंट विवरण शीट में सेव हुए ✓" },
    ib_lab_saved: { en: "Lab details saved to sheet ✓", mr: "लॅब तपशील शीटमध्ये सेव्ह झाले ✓", hi: "लैब विवरण शीट में सेव हुए ✓" },
    ib_no_b2b: { en: "B2B rate not set in Test Master — B2C rate used. Edit if needed.", mr: "टेस्ट मास्टरमध्ये B2B दर नाही — B2C दर वापरला आहे. हवा तर बदला.", hi: "टेस्ट मास्टर में B2B दर नहीं है — B2C दर लिया गया। चाहें तो बदलें।" },
    ib_saved: { en: "Bill saved to list ✓", mr: "बिल यादीत सेव्ह झालं ✓", hi: "बिल सूची में सेव हुआ ✓" }
  });

  /* ---------- helpers ---------- */
  const esc = (s) => escapeHtml(s);
  const num = (v) => Number(v) || 0;
  const rupee = (n) => "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 });
  const plain = (n) => Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 2, minimumFractionDigits: 2 });
  function fmtDate(s) {
    const m = String(s || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
    return m ? `${m[3]}-${m[2]}-${m[1]}` : String(s || "");
  }
  const pad2 = (x) => String(x).padStart(2, "0");
  function toISO(s) {
    s = String(s || "").trim();
    let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (m) return `${m[1]}-${pad2(m[2])}-${pad2(m[3])}`;
    m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})/);
    if (m) return `${m[3]}-${pad2(m[2])}-${pad2(m[1])}`;
    return "";
  }
  const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9\u0900-\u097f]+/g, " ").trim();
  function findMaster(name) {
    const n = norm(name);
    return n ? (ALL_DATA.tests || []).find((m) => norm(m.name) === n) : null;
  }

  /* ---- B2B क्लायंट लॅब्स + आपल्या लॅबचा प्रोफाईल: Google Sheet ("B2B Clients") + फोनवर कॅश ---- */
  const CLIENT_CACHE_KEY = "kp_b2b_clients";
  function localClients() { try { return JSON.parse(localStorage.getItem(CLIENT_CACHE_KEY) || "[]"); } catch (_) { return []; } }
  function allClients() {
    const map = {};
    localClients().forEach((c) => { if (c.name) map[norm(c.name)] = c; });
    (ALL_DATA.clients || []).filter((c) => (c.type || "CLIENT") === "CLIENT").forEach((c) => { if (c.name) map[norm(c.name)] = c; });   // शीट जिंकते
    return Object.values(map).sort((x, y) => x.name.localeCompare(y.name));
  }
  function rememberClient(c) {
    const list = localClients().filter((x) => norm(x.name) !== norm(c.name));
    list.push({ name: c.name, address: c.address, gstin: c.gstin, contact: c.contact, type: "CLIENT" });
    try { localStorage.setItem(CLIENT_CACHE_KEY, JSON.stringify(list)); } catch (_) {}
  }
  function selfProfile() {
    const row = (ALL_DATA.clients || []).find((c) => c.type === "SELF");
    const loc = loadProfile();
    return row ? { gstin: row.gstin || loc.gstin || "", reg: row.regNo || loc.reg || "", sign: row.signatory || loc.sign || "" } : { gstin: loc.gstin || "", reg: loc.reg || "", sign: loc.sign || "" };
  }

  function loadProfile() { try { return JSON.parse(localStorage.getItem(PROFILE_KEY) || "{}"); } catch (_) { return {}; } }
  function saveProfile(p) { try { localStorage.setItem(PROFILE_KEY, JSON.stringify(p)); } catch (_) {} }

  /* ---------- state ---------- */
  let inv = null;

  function nextBillNo(type) {
    const d = todayStr().replace(/-/g, "");
    const prefix = `${type}-${d}-`;
    let max = 0;
    (ALL_DATA.bills || []).forEach((b) => {
      const m = String(b.billNo || "").match(new RegExp("^" + prefix + "(\\d+)$"));
      if (m) max = Math.max(max, Number(m[1]));
    });
    return prefix + String(max + 1).padStart(3, "0");
  }

  function autoCollection() {
    if (!inv) return 0;
    if (inv.type === "B2B") return 0;
    const s = inv.lines.reduce((a, l) => a + num(l.rate), 0);
    return s > 0 && s < FREE_MIN ? CHARGE : 0;
  }

  /* टेस्ट मास्टरशी जुळवून बुकिंगमधील टेस्ट ओळखतो (नावात स्वल्पविराम असू शकतो) */
  function parseTests(str, master) {
    const orig = String(str || "");
    const low = orig.toLowerCase();
    let work = low;
    const found = [];
    const sorted = [...master].filter((m) => m.name).sort((a, b) => String(b.name).length - String(a.name).length);
    for (const m of sorted) {
      const nm = String(m.name).toLowerCase();
      const idx = work.indexOf(nm);
      if (idx >= 0) {
        found.push({ idx, m });
        work = work.slice(0, idx) + "\u0000".repeat(nm.length) + work.slice(idx + nm.length);
      }
    }
    found.sort((a, b) => a.idx - b.idx);
    const rest = work.replace(/\u0000+/g, ",").split(",").map((x) => x.trim()).filter((x) => x.length > 1);
    // leftover साठी मूळ अक्षर-रूप वापर
    const leftovers = rest.map((r) => { const p = low.indexOf(r); return p >= 0 ? orig.substr(p, r.length) : r; });
    return { found: found.map((f) => f.m), leftovers };
  }

  function lineFromMaster(m, type) {
    const b2c = num(m.price), b2b = num(m.b2b) || num(m.price);
    return { name: m.name, mrp: num(m.mrp) || b2c, b2c, b2b, costB2b: num(m.b2b), noB2b: !num(m.b2b), rate: type === "B2B" ? b2b : b2c, custom: false };
  }

  function baseInv(type) {
    const prof = selfProfile();
    return {
      type: type || "B2C", lang: "en", lines: [], collAuto: true, collection: 0, save: true, savedOnce: false,
      billNo: "", date: todayStr(), bookingRow: null, saveClient: true,
      patient: { name: "", age: "", gender: "", phone: "", address: "", doctor: "", pid: "", sampleDate: "", sampleTime: "", report: "" },
      client: { name: "", address: "", gstin: "", contact: "" },
      pay: { mode: "Cash", status: "Unpaid" },
      lab: { gstin: prof.gstin || "", reg: prof.reg || "", sign: prof.sign || "" }
    };
  }

  function openInvoiceFromBooking(rowNum) {
    const b = (ALL_DATA.bookings || []).find((x) => x.rowNum === Number(rowNum));
    if (!b) return;
    inv = baseInv("B2C");
    inv.bookingRow = b.rowNum;
    inv.patient = {
      name: b.fullName || "", age: b.age || "", gender: "", phone: String(b.phone || ""),
      address: [b.address, b.city].filter(Boolean).join(", "), doctor: b.doctor || "", pid: b.patientId || "",
      sampleDate: String(b.date || ""), sampleTime: String(b.time || ""), report: b.reportMode || ""
    };
    inv.pay.mode = /upi/i.test(b.paymentMethod || "") ? "UPI" : "Cash";
    inv.pay.status = b.status === "Completed" ? "Paid" : "Unpaid";
    const parsed = parseTests(b.tests, ALL_DATA.tests || []);
    inv.lines = parsed.found.map((m) => lineFromMaster(m, "B2C"));
    parsed.leftovers.forEach((n) => {
      const m = findMaster(n);   // थोडं वेगळं लिहिलेलं नाव असेल तरी मास्टरशी जुळवा
      inv.lines.push(m ? lineFromMaster(m, "B2C") : { name: n, mrp: 0, b2c: 0, b2b: 0, costB2b: 0, rate: 0, custom: true });
    });
    inv.collection = autoCollection();
    inv.billNo = nextBillNo("B2C");
    showModal();
  }

  function openInvoiceFromBill(rowNum) {
    const bill = (ALL_DATA.bills || []).find((x) => x.rowNum === Number(rowNum));
    if (!bill) return;
    const type = /^B2B-/.test(String(bill.billNo)) ? "B2B" : "B2C";
    inv = baseInv(type);
    inv.save = false; inv.savedOnce = true;
    inv.billNo = bill.billNo;
    inv.date = String(bill.date || todayStr()).slice(0, 10);
    inv.patient.name = bill.patient || "";
    // त्याच नावाचं ताजं बुकिंग असल्यास त्यातून तपशील भरा
    const bk = (ALL_DATA.bookings || []).find((x) => String(x.fullName).trim().toLowerCase() === String(bill.patient).trim().toLowerCase());
    if (bk) {
      Object.assign(inv.patient, { age: bk.age || "", phone: String(bk.phone || ""), address: [bk.address, bk.city].filter(Boolean).join(", "), doctor: bk.doctor || "", pid: bk.patientId || "", sampleDate: String(bk.date || ""), sampleTime: String(bk.time || ""), report: bk.reportMode || "" });
    }
    let coll = 0;
    (bill.tests || []).forEach((x) => {
      if (new RegExp("sample collection charge", "i").test(x.name || "")) { coll += num(x.b2c); return; }
      const m = findMaster(x.name);
      inv.lines.push({ name: x.name, mrp: num(x.mrp), b2c: num(x.b2c), b2b: m ? (num(m.b2b) || num(m.price)) : num(x.b2b), costB2b: num(x.b2b), noB2b: m ? !num(m.b2b) : false, rate: num(x.b2c), custom: !m });
    });
    inv.collAuto = false; inv.collection = coll;
    showModal();
  }
  window.openInvoiceFromBooking = openInvoiceFromBooking;
  window.openInvoiceFromBill = openInvoiceFromBill;

  /* ---------- calc ---------- */
  function calc() {
    const sumRate = inv.lines.reduce((a, l) => a + num(l.rate), 0);
    const sumMrp = inv.lines.reduce((a, l) => a + (num(l.mrp) || num(l.rate)), 0);
    const coll = num(inv.collection);
    return { sumRate, sumMrp, discount: Math.max(0, sumMrp - sumRate), coll, net: sumRate + coll, waived: inv.type === "B2C" && sumRate >= FREE_MIN };
  }

  /* ---------- modal (form) ---------- */
  function ensureModal() {
    let m = document.getElementById("invModal");
    if (m) return m;
    m = document.createElement("div");
    m.id = "invModal"; m.className = "inv-modal"; m.hidden = true;
    m.innerHTML = `<div class="inv-modal-sheet"><div class="inv-modal-head"><strong id="invModalTitle"></strong><button type="button" id="invModalClose" aria-label="Close">✕</button></div><div class="inv-modal-body" id="invModalBody"></div></div>`;
    document.body.appendChild(m);
    m.querySelector("#invModalClose").addEventListener("click", closeModal);
    m.addEventListener("click", (e) => { if (e.target === m) closeModal(); });
    const body = m.querySelector("#invModalBody");
    body.addEventListener("input", onInput);
    body.addEventListener("change", onInput);
    body.addEventListener("click", onClick);
    body.addEventListener("mousedown", (e) => { if (e.target.closest("#ibSuggest")) e.preventDefault(); });
    body.addEventListener("touchstart", (e) => { if (e.target.closest("#ibSuggest")) { const s = document.getElementById("ibSearch"); if (s) s.blur = s.blur; } }, { passive: true });
    return m;
  }
  function closeModal() { const m = document.getElementById("invModal"); if (m) m.hidden = true; }

  function fld(label, path, val, opts = {}) {
    if (opts.area) return `<label class="ib-field"><span>${label}</span><textarea data-f="${path}" rows="2">${esc(val)}</textarea></label>`;
    const type = opts.type ? ` type="${opts.type}"` : ' type="text"';
    const im = opts.inputmode ? ` inputmode="${opts.inputmode}"` : "";
    return `<label class="ib-field"><span>${label}</span><input${type}${im} data-f="${path}" value="${esc(val)}"></label>`;
  }

  function renderBody() {
    const body = document.getElementById("invModalBody");
    document.getElementById("invModalTitle").textContent = (inv.type === "QUOTE" ? "📄 " + t("ib_quote_title") : "🧾 " + t("ib_title")) + " · " + inv.billNo;
    const p = inv.patient, c = inv.client;
    const isB2B = inv.type === "B2B";
    const isQ = inv.type === "QUOTE";
    body.innerHTML = `
      ${isQ ? "" : `<div class="ib-seg" role="tablist">
        <button type="button" class="${!isB2B ? "on" : ""}" data-type="B2C">${t("ib_type_b2c")}</button>
        <button type="button" class="${isB2B ? "on" : ""}" data-type="B2B">${t("ib_type_b2b")}</button>
      </div>`}
      <label class="ib-field"><span>${t("ib_lang")}</span>
        <select data-f="lang"><option value="en" ${inv.lang === "en" ? "selected" : ""}>English</option><option value="mr" ${inv.lang === "mr" ? "selected" : ""}>मराठी</option><option value="hi" ${inv.lang === "hi" ? "selected" : ""}>हिंदी</option></select>
      </label>

      ${fld(isQ ? t("ib_quote_date") : t("ib_bill_date"), "date", toISO(inv.date) || todayStr(), { type: "date" })}
      ${isQ ? fld(t("ib_valid_till"), "validTill", toISO(inv.validTill), { type: "date" }) : ""}

      ${isB2B ? `<h4 class="ib-h">${t("ib_client")}</h4>
        ${allClients().length ? `<label class="ib-field"><span>${t("ib_saved_clients")}</span><select id="ibClientPick"><option value="">${t("ib_pick_client")}</option>${allClients().map((x) => `<option value="${esc(x.name)}" ${norm(x.name) === norm(c.name) ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></label>` : ""}
        ${fld(t("ib_client_name"), "client.name", c.name)}
        ${fld(t("ib_client_addr"), "client.address", c.address, { area: true })}
        <div class="ib-row">${fld(t("ib_client_gstin"), "client.gstin", c.gstin)}${fld(t("ib_client_contact"), "client.contact", c.contact)}</div>` : ""}

      <h4 class="ib-h">${t("ib_patient")}</h4>
      ${fld(t("ib_name"), "patient.name", p.name)}
      <div class="ib-row">${fld(t("ib_age"), "patient.age", p.age, { inputmode: "numeric" })}
        <label class="ib-field"><span>${t("ib_gender")}</span><select data-f="patient.gender">
          ${["", "Male", "Female", "Other"].map((g) => `<option value="${g}" ${p.gender === g ? "selected" : ""}>${g || "—"}</option>`).join("")}</select></label></div>
      <div class="ib-row">${fld(t("ib_mobile"), "patient.phone", p.phone, { type: "tel", inputmode: "numeric" })}${fld(isQ ? t("ib_pref_sample") : t("ib_sample_date"), "patient.sampleDate", toISO(p.sampleDate), { type: "date" })}</div>
      ${isQ ? fld(t("ib_email_f"), "patient.email", p.email || "", { type: "email" }) : fld(t("ib_sample_time"), "patient.sampleTime", p.sampleTime)}
      ${fld(t("ib_addr"), "patient.address", p.address, { area: true })}
      ${fld(t("ib_doc"), "patient.doctor", p.doctor)}

      <h4 class="ib-h">${t("ib_tests")}</h4>
      <div class="ib-suggest-wrap"><input type="text" id="ibSearch" placeholder="${esc(t("ib_search"))}" autocomplete="off" /><div id="ibSuggest" class="ib-suggest" hidden></div></div>
      <div class="ib-row ib-custom"><input type="text" id="ibCustomName" placeholder="${esc(t("ib_custom_name"))}" /><input type="number" id="ibCustomRate" placeholder="₹" min="0" inputmode="numeric" /><button type="button" id="ibCustomAdd" class="mini-btn approve">${t("ib_add")}</button></div>
      <div id="ibLines"></div>

      <label class="ib-field"><span>${t("ib_coll")}</span><input type="number" min="0" inputmode="numeric" id="ibColl" value="${num(inv.collection)}" /></label>
      <p class="ib-hint">${isB2B ? t("ib_coll_b2b") : t("ib_coll_b2c")}</p>
      <div id="ibTotals" class="ib-totals"></div>

      ${isQ ? fld(t("ib_notes"), "notes", inv.notes || "", { area: true }) : `<h4 class="ib-h">${t("ib_pay")}</h4>
      <div class="ib-row">
        <label class="ib-field"><span>${t("ib_pay_mode")}</span><select data-f="pay.mode">${["Cash", "UPI", "Card", "Bank Transfer", "Credit"].map((x) => `<option ${inv.pay.mode === x ? "selected" : ""}>${x}</option>`).join("")}</select></label>
        <label class="ib-field"><span>${t("ib_pay_status")}</span><select data-f="pay.status"><option value="Paid" ${inv.pay.status === "Paid" ? "selected" : ""}>${t("ib_paid")}</option><option value="Unpaid" ${inv.pay.status !== "Paid" ? "selected" : ""}>${t("ib_unpaid")}</option></select></label>
      </div>`}

      <details class="ib-details"><summary>${t("ib_lab")}</summary>
        ${fld(t("ib_lab_gstin"), "lab.gstin", inv.lab.gstin)}
        ${fld(t("ib_lab_reg"), "lab.reg", inv.lab.reg)}
        ${fld(t("ib_lab_sign"), "lab.sign", inv.lab.sign)}
      </details>

      ${isQ ? "" : isB2B ? `<label class="ib-check"><input type="checkbox" id="ibSaveClient" ${inv.saveClient ? "checked" : ""}/> <span>${t("ib_save_client")}</span></label><p class="ib-hint">${t("ib_b2b_nosave")}</p>` : `<label class="ib-check"><input type="checkbox" id="ibSave" ${inv.save && !inv.savedOnce ? "checked" : ""} ${inv.savedOnce ? "disabled" : ""}/> <span>${t("ib_save_list")}</span></label>`}
      <button type="button" class="btn btn-block" id="ibPreview" style="background:var(--navy);color:#fff;margin-top:6px">${isQ ? t("ib_quote_preview") : t("ib_preview")}</button>`;
    renderLines();
  }

  function renderLines() {
    const wrap = document.getElementById("ibLines");
    if (!wrap) return;
    const isB2B = inv.type === "B2B";
    wrap.innerHTML = inv.lines.length === 0 ? `<p class="ib-hint">${t("ib_no_lines")}</p>` : inv.lines.map((l, i) => `
      <div class="ib-line">
        <div class="ib-line-name">${esc(l.name)}</div>
        <div class="ib-line-nums">
          ${!isB2B ? `<label><span>${t("ib_mrp")}</span><input type="number" min="0" inputmode="numeric" data-li="${i}" data-lk="mrp" value="${num(l.mrp)}"></label>` : ""}
          <label><span>${t("ib_rate")}</span><input type="number" min="0" inputmode="numeric" data-li="${i}" data-lk="rate" value="${num(l.rate)}"></label>
          <button type="button" class="ib-x" data-rm="${i}" aria-label="Remove">✕</button>
        </div>
        ${isB2B && l.noB2b && !l.custom ? `<div class="ib-warn">⚠ ${t("ib_no_b2b")}</div>` : ""}
      </div>`).join("");
    renderTotals();
  }

  function renderTotals() {
    const box = document.getElementById("ibTotals");
    if (!box) return;
    const c = calc();
    const collCell = c.waived && c.coll === 0 ? `<s>${rupee(CHARGE)}</s> ${t("ib_waived")}` : rupee(c.coll);
    box.innerHTML = `
      <div><span>${t("ib_sub")}</span><b>${rupee(c.sumRate)}</b></div>
      <div><span>${t("ib_coll_line")}</span><b>${collCell}</b></div>
      <div class="net"><span>${t("ib_net")}</span><b>${rupee(c.net)}</b></div>`;
    const coll = document.getElementById("ibColl");
    if (coll && document.activeElement !== coll) coll.value = num(inv.collection);
  }

  function setPath(path, val) {
    const parts = path.split(".");
    let o = inv;
    for (let i = 0; i < parts.length - 1; i++) o = o[parts[i]];
    o[parts[parts.length - 1]] = val;
  }

  function onInput(e) {
    const el = e.target;
    if (el.id === "ibClientPick") { fillClient(el.value); return; }
    if (el.id === "ibSaveClient") { inv.saveClient = el.checked; return; }
    if (el.dataset.f) {
      setPath(el.dataset.f, el.value);
      // क्लायंटचं नाव सेव्ह केलेल्या नावाशी जुळलं तर बाकी तपशील आपोआप भरा
      if (el.dataset.f === "client.name" && e.type === "change") fillClient(el.value, true);
      return;
    }
    if (el.dataset.li !== undefined) {
      const i = Number(el.dataset.li), k = el.dataset.lk;
      inv.lines[i][k] = num(el.value);
      if (inv.collAuto) inv.collection = autoCollection();
      renderTotals();
      return;
    }
    if (el.id === "ibColl") { inv.collection = num(el.value); inv.collAuto = false; renderTotals(); return; }
    if (el.id === "ibSave") { inv.save = el.checked; return; }
    if (el.id === "ibSearch") {
      if (e.type !== "input") return;   // blur वरचा change इव्हेंट सूचना-यादी पुन्हा तयार करून टॅप गिळू नये
      const term = el.value.trim().toLowerCase();
      const box = document.getElementById("ibSuggest");
      if (!term) { box.hidden = true; return; }
      const matches = (ALL_DATA.tests || []).filter((x) => String(x.name).toLowerCase().includes(term)).slice(0, 8);
      box.innerHTML = matches.map((x, i) => `<div data-sug="${i}"><strong>${esc(x.name)}</strong><br><small>MRP ₹${x.mrp} · B2C ₹${x.price} · B2B ₹${x.b2b || 0}</small></div>`).join("") || `<div class="ib-none">—</div>`;
      box._m = matches; box.hidden = false;
    }
  }

  function fillClient(name, onlyIfEmpty) {
    const c = allClients().find((x) => norm(x.name) === norm(name));
    if (!c) return;
    const cur = inv.client;
    if (onlyIfEmpty && (cur.address || cur.gstin || cur.contact)) return;
    inv.client = { name: c.name, address: c.address || "", gstin: c.gstin || "", contact: c.contact || "" };
    renderBody();
  }

  function onClick(e) {
    const el = e.target;
    const typeBtn = el.closest("[data-type]");
    if (typeBtn) {
      const type = typeBtn.dataset.type;
      if (type === inv.type) return;
      inv.type = type;
      inv.billNo = nextBillNo(type);
      inv.lines.forEach((l) => {
        if (l.custom) {
          const m = findMaster(l.name);
          if (m) { Object.assign(l, lineFromMaster(m, type)); l.custom = false; }
          return;
        }
        l.rate = type === "B2B" ? l.b2b : l.b2c;   // B2B निवडल्यावर टेस्ट मास्टरचा B2B दर आपोआप
      });
      inv.collAuto = true; inv.collection = autoCollection();
      renderBody();
      return;
    }
    const rm = el.closest("[data-rm]");
    if (rm) { inv.lines.splice(Number(rm.dataset.rm), 1); if (inv.collAuto) inv.collection = autoCollection(); renderLines(); return; }
    const sug = el.closest("[data-sug]");
    if (sug) {
      const box = document.getElementById("ibSuggest");
      const m = box._m[Number(sug.dataset.sug)];
      if (m && !inv.lines.some((l) => l.name.toLowerCase() === m.name.toLowerCase())) {
        inv.lines.push(lineFromMaster(m, inv.type));
        if (inv.collAuto) inv.collection = autoCollection();
      }
      box.hidden = true; document.getElementById("ibSearch").value = "";
      renderLines();
      return;
    }
    if (el.id === "ibCustomAdd") {
      const n = document.getElementById("ibCustomName").value.trim();
      const r = num(document.getElementById("ibCustomRate").value);
      if (!n) return;
      inv.lines.push({ name: n, mrp: r, b2c: r, b2b: r, costB2b: 0, rate: r, custom: true });
      document.getElementById("ibCustomName").value = ""; document.getElementById("ibCustomRate").value = "";
      if (inv.collAuto) inv.collection = autoCollection();
      renderLines();
      return;
    }
    if (el.id === "ibPreview") doPreview();
  }

  function showModal() {
    const m = ensureModal();
    renderBody();
    m.hidden = false;
    document.getElementById("invModalBody").scrollTop = 0;
  }

  /* ---------- save to Bills list (existing addBill action) ---------- */
  function saveToBills() {
    const c = calc();
    const tests = inv.lines.map((l) => ({ name: l.name, mrp: num(l.mrp) || num(l.rate), b2c: num(l.rate), b2b: num(l.costB2b), collection: 0, report: 0 }));
    if (c.coll > 0) tests.push({ name: CHARGE_LINE_NAME, mrp: c.coll, b2c: c.coll, b2b: 0, collection: 0, report: 0 });
    const mrp = tests.reduce((a, x) => a + x.mrp, 0), b2c = tests.reduce((a, x) => a + x.b2c, 0), b2b = tests.reduce((a, x) => a + x.b2b, 0);
    const payload = { billNo: inv.billNo, date: inv.date, patient: inv.patient.name.trim(), tests, mrp, b2c, b2b, collection: 0, report: 0, discount: mrp - b2c, profit: b2c - b2b };
    // त्याच पेशंटचं त्याच दिवसाचं तेच बिल आधीच असेल तर नवी नोंद न करता तीच अपडेट करा (शीटमध्ये डुप्लिकेट नको)
    const key = (x) => String(x.patient).trim().toLowerCase() + "|" + String(x.date).slice(0, 10);
    const names = (arr) => (arr || []).map((x) => norm(x.name)).filter((n) => n !== norm(CHARGE_LINE_NAME)).sort().join("|");
    const existing = (ALL_DATA.bills || []).find((x) => key(x) === key(payload) && names(x.tests) === names(tests) && /^B2C-/.test(String(x.billNo)));
    if (existing) {
      payload.billNo = existing.billNo; inv.billNo = existing.billNo;
      if (existing.rowNum >= 2) postAdminAction({ action: "updateBill", rowNum: existing.rowNum, ...payload }, t("ib_saved"));
    } else {
      postAdminAction({ action: "addBill", ...payload }, t("ib_saved"));
      (ALL_DATA.bills = ALL_DATA.bills || []).push({ rowNum: -1, ...payload });   // लगेच पुन्हा उघडलं तरी डुप्लिकेट होऊ नये
    }
  }


  /* क्लायंट लॅबचे तपशील + आपल्या लॅबचे तपशील Google Sheet मध्ये सेव्ह (पुढच्या वेळी आपोआप दिसतात) */
  function syncToSheet() {
    const prevSelf = selfProfile();
    const selfChanged = prevSelf.gstin !== (inv.lab.gstin || "") || prevSelf.reg !== (inv.lab.reg || "") || prevSelf.sign !== (inv.lab.sign || "");
    if (selfChanged && (inv.lab.gstin || inv.lab.reg || inv.lab.sign)) {
      const rows = (ALL_DATA.clients = ALL_DATA.clients || []).filter((x) => x.type !== "SELF");
      rows.push({ name: LAB.name, gstin: inv.lab.gstin, regNo: inv.lab.reg, signatory: inv.lab.sign, type: "SELF" });
      ALL_DATA.clients = rows;
      postAdminAction({ action: "saveClient", clientType: "SELF", name: LAB.name, gstin: inv.lab.gstin, regNo: inv.lab.reg, signatory: inv.lab.sign }, t("ib_lab_saved"));
    }
    if (inv.type === "B2B" && inv.saveClient && inv.client.name.trim()) {
      const c = inv.client;
      const old = allClients().find((x) => norm(x.name) === norm(c.name));
      const same = old && (old.address || "") === (c.address || "") && (old.gstin || "") === (c.gstin || "") && (old.contact || "") === (c.contact || "");
      if (!same) {
        rememberClient(c);
        postAdminAction({ action: "saveClient", clientType: "CLIENT", name: c.name.trim(), address: c.address, gstin: c.gstin, contact: c.contact }, t("ib_client_saved"));
      }
    }
  }

  function addDays(iso, n) {
    const d = new Date(iso + "T00:00:00"); d.setDate(d.getDate() + n);
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
  }
  function nextQuoteNo() {
    const d = todayStr().replace(/-/g, ""), key = "kp_quote_seq_" + d;
    const n = Number(localStorage.getItem(key) || 0) + 1;
    try { localStorage.setItem(key, String(n)); } catch (_) {}
    return `QT-${d}-${String(n).padStart(3, "0")}`;
  }
  function openQuotation() {
    inv = baseInv("QUOTE");
    inv.billNo = nextQuoteNo();
    inv.validTill = addDays(todayStr(), 7);
    inv.notes = "";
    inv.save = false; inv.savedOnce = true;
    inv.collection = 0;
    showModal();
  }
  window.openQuotation = openQuotation;

  function doPreview() {
    if (!inv.patient.name.trim()) { showToast(t("ib_err_name")); return; }
    if (inv.type === "B2B" && !inv.client.name.trim()) { showToast(t("ib_err_client")); return; }
    if (inv.lines.length === 0) { showToast(t("ib_err_lines")); return; }
    inv.date = toISO(inv.date) || todayStr();
    if (inv.type === "QUOTE") inv.validTill = toISO(inv.validTill) || addDays(inv.date, 7);
    saveProfile({ gstin: inv.lab.gstin, reg: inv.lab.reg, sign: inv.lab.sign });
    syncToSheet();
    if (inv.type === "B2C" && inv.save && !inv.savedOnce) { saveToBills(); inv.savedOnce = true; }
    showInvoice();
  }

  /* ---------- the printable invoice ---------- */
  function ensureOverlay() {
    let o = document.getElementById("invoiceOverlay");
    if (o) return o;
    o = document.createElement("div");
    o.id = "invoiceOverlay"; o.hidden = true;
    o.innerHTML = `
      <div class="inv-toolbar">
        <button type="button" id="invBack"></button>
        <button type="button" id="invPrint" class="primary"></button>
        <button type="button" id="invPdf"></button>
        <button type="button" id="invShare"></button>
        <button type="button" id="invWa"></button>
        <button type="button" id="invMail"></button>
      </div>
      <div class="inv-scroll"><div id="invScaleWrap"><div id="invSheet"></div></div></div>`;
    document.body.appendChild(o);
    o.querySelector("#invBack").addEventListener("click", () => { o.hidden = true; });
    o.querySelector("#invPrint").addEventListener("click", () => window.print());
    o.querySelector("#invWa").addEventListener("click", shareWhatsApp);
    o.querySelector("#invMail").addEventListener("click", shareEmail);
    o.querySelector("#invPdf").addEventListener("click", downloadPdf);
    o.querySelector("#invShare").addEventListener("click", sharePdf);
    window.addEventListener("resize", () => { if (!o.hidden) fitSheet(); });
    return o;
  }

  function fitSheet() {
    const sheet = document.getElementById("invSheet"), wrap = document.getElementById("invScaleWrap");
    const scale = Math.min(1, (window.innerWidth - 16) / 794);
    sheet.style.transform = `scale(${scale})`;
    wrap.style.width = Math.round(794 * scale) + "px";
    wrap.style.height = Math.round(sheet.offsetHeight * scale) + "px";
  }

  function showInvoice() {
    const o = ensureOverlay();
    o.querySelector("#invBack").textContent = t("ib_back_edit");
    o.querySelector("#invPrint").textContent = t("ib_print");
    o.querySelector("#invWa").textContent = t("ib_wa");
    o.querySelector("#invMail").textContent = t("ib_email_btn");
    o.querySelector("#invPdf").textContent = t("ib_pdf");
    o.querySelector("#invShare").textContent = t("ib_share");
    document.getElementById("invSheet").innerHTML = KPInv.html(inv, { upi: upiId() });
    o.hidden = false;
    o.querySelector(".inv-scroll").scrollTop = 0;
    fitSheet();
    // लोगो नंतर लोड झाल्यावर उंची पुन्हा मोजा
    const img = o.querySelector(".inv-logo");
    if (img) img.addEventListener("load", fitSheet);
  }

  function upiId() { return (ALL_DATA.settings && ALL_DATA.settings.upiId) || "enterprises60658@nyes"; }

  /* ---- PDF फाईल: डाउनलोड + शेअर ---- */
  async function makePdf() {
    showToast("PDF…");
    try { return await KPInv.pdfBlob(inv, { upi: upiId() }); } catch (e) { showToast("PDF error — Print वापरा"); return null; }
  }
  function pdfName() { return `${inv.billNo}.pdf`; }
  async function downloadPdf() {
    const blob = await makePdf(); if (!blob) return;
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = pdfName();
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  async function sharePdf() {
    const blob = await makePdf(); if (!blob) return;
    const file = new File([blob], pdfName(), { type: "application/pdf" });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try { await navigator.share({ files: [file], title: pdfName(), text: `${LAB.name} — ${inv.billNo}` }); } catch (_) {}
    } else { shareWhatsApp(); }
  }

  function shareWhatsApp() {
    const digits = String(inv.patient.phone || "").replace(/\D/g, "").slice(-10);
    const to = digits.length === 10 ? "91" + digits : "";
    window.open(`https://wa.me/${to}?text=${encodeURIComponent(KPInv.text(inv))}`, "_blank");
  }
  function shareEmail() {
    const kind = inv.type === "QUOTE" ? "Quotation" : inv.type === "B2B" ? "Invoice" : "Bill";
    const to = inv.type === "B2B" ? "" : (inv.patient.email || "");
    window.location.href = `mailto:${encodeURIComponent(to)}?subject=${encodeURIComponent(`${kind} ${inv.billNo} — Kalyan Pathlab`)}&body=${encodeURIComponent(KPInv.text(inv, true))}`;
  }

  /* ---- Admin मध्ये "नवे कोटेशन" बटण (टेस्ट व बिलिंग टॅबवर) ---- */
  ["tab-tests", "tab-billing"].forEach((id) => {
    const sec = document.getElementById(id);
    if (!sec || sec.querySelector(".quote-open-btn")) return;
    const btn = document.createElement("button");
    btn.type = "button"; btn.className = "btn btn-block quote-open-btn";
    btn.textContent = t("ib_quote_btn");
    btn.addEventListener("click", openQuotation);
    sec.insertBefore(btn, sec.firstChild);
  });
})();
