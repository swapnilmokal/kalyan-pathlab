# Claude AI Prompt — Kalyan Pathlab PWA Repair & Professional Upgrade

You are repairing and finalizing the Kalyan Pathlab GitHub Pages PWA.

LIVE URL:
https://swapnilmokal.github.io/kalyan-pathlab/

ADMIN URL:
https://swapnilmokal.github.io/kalyan-pathlab/admin.html

## CRITICAL BUG TO FIX FIRST
The current project has a deployment/path mismatch. The supplied package may contain a `book/` parent directory. The GitHub Pages project root must contain `index.html` directly.

DO NOT create:
book/index.html
book/icons/
book/style.css

Instead the repository root must contain:
index.html
admin.html
app.js
admin.js
i18n.js
tests-data.js
style.css
admin-style.css
sw.js
manifest.json
manifest-admin.json
icons/

All asset references must be relative to the file using `./...` so they work on:
https://swapnilmokal.github.io/kalyan-pathlab/

## ICON/PWA REQUIREMENTS
Use the supplied Kalyan Pathlab assets from `icons/`.

Customer:
- icons/logo.png
- icons/icon-192.png
- icons/icon-512.png
- icons/favicon-32.png
- icons/apple-touch-icon.png
- icons/qr.png

Admin:
- icons/admin-logo.png
- icons/admin-icon-192.png
- icons/admin-icon-512.png

Use:
<link rel="manifest" href="./manifest.json">
<link rel="icon" type="image/png" sizes="32x32" href="./icons/favicon-32.png">
<link rel="icon" type="image/png" sizes="192x192" href="./icons/icon-192.png">
<link rel="apple-touch-icon" sizes="180x180" href="./icons/apple-touch-icon.png">

manifest.json:
- start_url: "./"
- scope: "./"
- id: "./"
- display: "standalone"
- icons must use "./icons/icon-192.png" and "./icons/icon-512.png"
- 512 icon should support `any maskable`

manifest-admin.json:
- start_url: "./admin.html"
- scope: "./"
- id: "./admin.html"
- admin icon paths must start with "./icons/"

## SERVICE WORKER
Keep registration:
navigator.serviceWorker.register("./sw.js")

Do not cache incorrect/old paths.
Use a new cache version whenever assets change.
Do not let an old service worker permanently serve an old index.
On activate, delete older `kalyan-pathlab-*` caches and call clients.claim().

## FUNCTIONALITY
Do not remove existing functionality.
Keep:
- Marathi / Hindi / English
- test search and price list
- multi-step booking
- home sample collection
- location option
- WhatsApp booking
- UPI QR
- booking status
- reviews
- customer/admin separation
- test data
- report link support
- Google Sheet/Drive links already present in admin configuration

## PROFESSIONAL UI
Improve the visual design without changing the business logic:
- professional diagnostic-lab appearance
- responsive mobile-first design
- clear CTA: “आत्ता बुक करा”
- attractive discount cards
- professional test cards
- proper icons instead of relying only on emoji
- accessible buttons
- good loading/empty/error states
- fast loading
- no broken images
- no console errors

## ICON RULE
Do not use remote icon libraries as the only icon source.
Use local SVG icons or the supplied PNG assets so the application still works if an external CDN is unavailable.
Do not rename supplied icon files unless all references are updated.

## LINK/ASSET AUDIT
Before finishing, audit EVERY:
- img src
- script src
- stylesheet href
- manifest href
- favicon href
- service-worker registration
- internal page link

Every local file must resolve from the GitHub Pages project root.

## GITHUB PAGES RULE
This is a project site, not a domain root.
The final application must work exactly at:
https://swapnilmokal.github.io/kalyan-pathlab/

Do not assume `/icons/...` is available at the domain root.
Prefer `./icons/...`.

## CACHE/UPDATE RULE
Add a visible developer-safe version constant, for example:
APP_VERSION = "2026.10.04"

When assets change:
- update service worker cache version
- ensure activate removes old Kalyan Pathlab caches

## FINAL QA CHECKLIST
Test:
1. Customer URL opens.
2. Kalyan Pathlab logo appears.
3. Browser favicon appears.
4. Add-to-home-screen uses Kalyan Pathlab icon.
5. 192 and 512 PWA icons load.
6. QR image appears.
7. CSS loads.
8. JavaScript loads.
9. Test list appears.
10. Booking works.
11. WhatsApp link works.
12. Admin page opens.
13. Admin icon loads.
14. No 404 asset requests.
15. No JavaScript console errors.
16. Refresh does not break the application.
17. Offline fallback works after first successful load.

## IMPORTANT
Do not merely explain the bug. Actually repair the files.
Return the complete corrected project files, preserving existing business data and functionality.
The repository should be ready to upload directly to GitHub Pages root.
