# Kalyan Pathlab — GitHub Pages Ready Package

## Correct upload structure
Upload the CONTENTS of this folder directly into the root of the GitHub repository.

Correct:
- index.html
- admin.html
- app.js
- style.css
- i18n.js
- tests-data.js
- sw.js
- manifest.json
- manifest-admin.json
- icons/

Incorrect:
- book/index.html
- book/icons/...
- while opening https://YOUR-USER.github.io/kalyan-pathlab/

The previous package had a `book/` parent folder. If that folder was uploaded as-is, the GitHub Pages root and asset paths could point to different locations.

## Expected URLs
Customer:
https://swapnilmokal.github.io/kalyan-pathlab/

Admin:
https://swapnilmokal.github.io/kalyan-pathlab/admin.html

## After deployment
1. GitHub repository → Settings → Pages → Deploy from branch → main → / (root).
2. Wait for deployment.
3. Open the customer URL.
4. If an old PWA is installed, uninstall/remove the old home-screen app and reopen the site.
5. Hard refresh once. The new service worker uses cache `kalyan-pathlab-v20`.
