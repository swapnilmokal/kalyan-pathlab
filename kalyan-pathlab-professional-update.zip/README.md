# Kalyan Pathlab — UI/Icon Fix Package

## मुख्य समस्या
GitHub repository मध्ये `icons/` folder दिसत नाही, पण `index.html`, `manifest.json` आणि `admin.html` हे अनेक files `./icons/...` assets वापरतात. त्यामुळे browser मध्ये logo, PWA icon आणि UPI QR सारख्या images साठी broken-image/रिकामी जागा दिसते.

## या ZIP मध्ये
- `icons/logo.png` — customer app logo
- `icons/icon-192.png` — PWA icon
- `icons/icon-512.png` — PWA/OG icon
- `icons/icon-512-maskable.png` — maskable PWA icon
- `icons/admin-logo.png` — admin logo
- `icons/admin-icon-192.png` — admin favicon/PWA icon
- `icons/qr.png` — existing UPI ID `enterprises60658@nyes` साठी QR
- `professional-overrides.css` — optional UI polish
- `ui-enhancements.js` — optional share/fallback UX
- `GITHUB_UPDATE.md` — exact update steps

## महत्त्वाचे
हा package **पूर्ण repository replacement नाही**. Existing files सुरक्षित ठेवून हे assets add करणे आणि optional CSS/JS दोन छोट्या links ने जोडणे हा सुरक्षित मार्ग आहे.
